//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by reversi_gui.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_REVERSTYPE                  129
#define ID_PLAY_START                   32771
#define ID_PLAY_BREAK                   32772
#define ID_PLAY_UNDO                    32773
#define ID_PLAY_BLACK                   32774
#define ID_PLAY_WHITE                   32775
#define ID_PLAY_LEVEL1                  32776
#define ID_PLAY_LEVEL2                  32777
#define ID_PLAY_LEVEL3                  32778
#define ID_PLAY_LEVEL4                  32779
#define ID_PLAY_LEVEL5                  32780
#define ID_PLAY_LEVEL6                  32781
#define ID_PLAY_LEVEL7                  32782
#define ID_PLAY_LEVEL8                  32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
